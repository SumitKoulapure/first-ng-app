import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-register-category',
  imports: [],
  templateUrl: './register-category.html',
  styleUrl: './register-category.css',
})
export class RegisterCategory {

}
