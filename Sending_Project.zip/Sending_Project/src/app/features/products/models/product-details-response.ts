import { ProductData } from "./product-data";

export class ProductDetailsResponse {
    success: boolean;
    data: ProductData;
}
