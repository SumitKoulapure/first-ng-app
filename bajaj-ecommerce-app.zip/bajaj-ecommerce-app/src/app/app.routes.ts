import { Routes } from '@angular/router';

import { Home } from './shared/components/home/home';

import { productsRoutes } from './features/products/products.routes';
import { SecurityRoutes } from './features/security/security.routes';
import { CategoriesLists } from './features/categories/components/categories-lists/categories-lists';

export const routes: Routes = [
  {
    path: '',
    component: Home,
    title: 'Home',
  },
  {
    path: 'home',
    component: Home,
    title: 'Home',
  },
  {
    path: 'category',
    component: CategoriesLists,
  },
  {
    path: 'auth',
    children: [...SecurityRoutes],
  },
  {
    path: 'products',
    children: productsRoutes,
  },
  
  
];
