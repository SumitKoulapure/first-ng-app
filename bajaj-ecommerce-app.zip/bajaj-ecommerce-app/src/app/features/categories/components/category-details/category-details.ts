import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-category-details',
  imports: [],
  templateUrl: './category-details.html',
  styleUrl: './category-details.css',
})
export class CategoryDetails {

}
