import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ProductsApi } from '../../services/products-api';

@Component({
  selector: 'bajaj-product-details',
  imports: [CommonModule, RouterLink],
  templateUrl: './product-details.html',
  styleUrl: './product-details.css',
})
export class ProductDetails implements OnInit {
  private route = inject(ActivatedRoute);
  private _productsApi = inject(ProductsApi);

  product: any = null;
  productId: string = '';

  ngOnInit(): void {
    this.productId = this.route.snapshot.paramMap.get('id')!;
    this._productsApi.getProductById(this.productId).subscribe({
      next: (res) => (this.product = res.data),
      error: (err) => console.error(err),
    });
  }
}
