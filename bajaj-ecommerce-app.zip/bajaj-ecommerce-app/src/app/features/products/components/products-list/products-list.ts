import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { Product, ProductData } from '../../models/product';
import { Subscription } from 'rxjs';
import { ProductsApi } from '../../services/products-api';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

@Component({
  selector: 'bajaj-products-list',
  imports: [CommonModule, NgxPaginationModule, FormsModule, RouterLink],
  templateUrl: './products-list.html',
  standalone: true,
  styleUrl: './products-list.css',
})
export class ProductsList implements OnInit, OnDestroy {
  private _productsApi = inject(ProductsApi);
  private _Activatedroute = inject(ActivatedRoute);
  private _productsServiceSubscription: Subscription;

  protected pageNumber: number = 1;
  protected pageSize: number = 10;
  protected totalItems: number = 0;
  protected totalPages: number = 0;
  protected isLoading: boolean = false;

  protected products: ProductData[] = [];
  protected category: string | null = null;
  constructor(private router: Router) {}

  goToDetails(id: string) {
    this.router.navigate(['/products', id]);
  }

  ngOnInit(): void {
    this._Activatedroute.paramMap.subscribe((params) => {
      this.category = params.get('category');
    });

    this._Activatedroute.queryParamMap.subscribe((queryParams) => {
      const keyword = queryParams.get('keyword');
      if (keyword) {
        this.searchProducts(keyword);
      } else {
        this.loadProducts(this.pageNumber);
      }
    });
  }

  loadProducts(page: number) {
    this.isLoading = true;

    if (this._productsServiceSubscription) {
      this._productsServiceSubscription.unsubscribe();
    }

    if (this.category) {
      // ✅ Fetch products by category
      this._productsServiceSubscription = this._productsApi
        .getProductsByCategory(this.category)
        .subscribe({
          next: (res) => {
            this.products = res.data;
            this.isLoading = false;
          },
          error: (err) => {
            console.log(err);
            this.isLoading = false;
          },
        });
    } else {
      this._productsServiceSubscription = this._productsApi
        .getProducts(page, this.pageSize)
        .subscribe({
          next: (res) => {
            this.products = res.data;
            this.totalItems = res.total;
            this.totalPages = Math.ceil(res.total / this.pageSize);
            this.isLoading = false;
          },
          error: (err) => console.log(err),
        });
    }
  }

  onPageChange(newPage: number) {
    if (newPage < 1 || newPage > this.totalPages) return;
    this.pageNumber = newPage;
    this.loadProducts(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  getPageNumbers(): number[] {
    const range: number[] = [];
    const maxVisible = 5; // show up to 5 numbers at a time
    let start = Math.max(1, this.pageNumber - Math.floor(maxVisible / 2));
    let end = Math.min(this.totalPages, start + maxVisible - 1);

    if (end - start < maxVisible - 1) {
      start = Math.max(1, end - maxVisible + 1);
    }

    for (let i = start; i <= end; i++) {
      range.push(i);
    }
    return range;
  }

  searchProducts(keyword: string) {
    this.isLoading = true;

    if (this._productsServiceSubscription) {
      this._productsServiceSubscription.unsubscribe();
    }

    this._productsServiceSubscription = this._productsApi.searchProducts(keyword).subscribe({
      next: (res) => {
        this.products = res.data;
        this.totalItems = res.total || res.data.length;
        this.isLoading = false;
      },
      error: (err) => {
        console.log(err);
        this.isLoading = false;
      },
    });
  }

  ngOnDestroy(): void {
    if (this._productsServiceSubscription) {
      this._productsServiceSubscription.unsubscribe();
    }
  }
}
