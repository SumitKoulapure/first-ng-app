import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserApi } from '../../../services/user-api';
import { User } from '../../../models/user';

@Component({
  selector: 'bajaj-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './register.html',
  styleUrl: './register.css',
})
export class Register {
  registerForm: FormGroup;
  isSubmitting = false;
  message = '';

  constructor(private fb: FormBuilder, private userApi: UserApi) {
    this.registerForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      passwordHash: ['', [Validators.required, Validators.minLength(6)]],
      role: ['customer'], // Default role
      phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      addresses: this.fb.array([this.createAddressGroup()])
    });
  }

  // 🏠 Create Address FormGroup
  createAddressGroup(): FormGroup {
    return this.fb.group({
      label: ['Home', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      postalCode: ['', [Validators.required, Validators.pattern(/^[0-9]{6}$/)]],
      country: ['India', Validators.required],
      isDefault: [true]
    });
  }

  // 🧾 Getter for FormArray
  get addresses(): FormArray {
    return this.registerForm.get('addresses') as FormArray;
  }

  // ➕ Add New Address
  addAddress(): void {
    this.addresses.push(this.createAddressGroup());
  }

  // ➖ Remove Address
  removeAddress(index: number): void {
    this.addresses.removeAt(index);
  }

  // ✅ Submit Registration Form
  onSubmit(): void {
    if (this.registerForm.invalid) {
      this.message = 'Please fill in all required fields correctly.';
      return;
    }

    this.isSubmitting = true;

    const userData: User = this.registerForm.value;

    console.log('📤 Sending data to backend:', userData);

    // Send to backend
    this.userApi.registerUser(userData).subscribe({
      next: (response) => {
        console.log('✅ Registration successful:', response);
        this.message = 'Registration successful! 🎉';
        this.isSubmitting = false;
        this.registerForm.reset();

        // Reinitialize default address
        this.addresses.clear();
        this.addresses.push(this.createAddressGroup());
      },
      error: (error) => {
        console.error('❌ Registration failed:', error);
        this.message = 'Registration failed. Please try again.';
        this.isSubmitting = false;
      }
    });
  }
}
