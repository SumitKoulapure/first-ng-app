import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root',
})
export class UserApi {
  private _http = inject(HttpClient);
  private _baseUrl = 'http://localhost:9090/api/auth';

registerUser(user: User): Observable<any> {
    // In backend, often field is 'password', not 'passwordHash'
    const { passwordHash, ...rest } = user;
    const mappedUser = { 
      ...rest, 
      password: passwordHash 
    };

    return this._http.post(`${this._baseUrl}/register`, mappedUser);
  }
  // Login
  loginUser(credentials: { email: string; password: string }): Observable<any> {
    return this._http.post(`${this._baseUrl}/login`, credentials);
  }

  // Get user by ID (optional)
  getUserById(id: string): Observable<User> {
    return this._http.get<User>(`${this._baseUrl}/${id}`);
  }
}