import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';

import { Subject, debounceTime } from 'rxjs';

@Component({
  selector: 'bajaj-navbar',
  imports: [RouterLink, RouterLinkActive, CommonModule, FormsModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {
  protected isLoggedIn: boolean = false;
  searchQuery: string = '';
  private _router = inject(Router);
  private searchSubject = new Subject<string>();

  ngOnInit() {
    this.searchSubject.pipe(debounceTime(500)).subscribe((query) => {
      if (query.trim()) {
        // 🔍 Navigate to search results page dynamically
        this._router.navigate(['/products'], {
          queryParams: { keyword: query },
        });
      } else {
        // 🧹 Clear search results when box is empty
        this._router.navigate(['/products'], { queryParams: {} });
      }
    });
  }

  onSearch(event: Event) {
    // event.preventDefault();

    // if (this.searchQuery.trim()) {
    //   this._router.navigate(['/products'], {
    //     queryParams: { keyword: this.searchQuery },
    //   });
    // }
    this.searchSubject.next(this.searchQuery);
  }

  logout(): void {
    localStorage.clear();
    this.isLoggedIn = false;
  }
}
