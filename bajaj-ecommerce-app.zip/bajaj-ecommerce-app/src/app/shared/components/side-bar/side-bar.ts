import { Component, ViewChild, ElementRef, AfterViewInit } from '@angular/core';

@Component({
  selector: 'bajaj-side-bar',
  templateUrl: './side-bar.html',
  styleUrls: ['./side-bar.css'],
})
export class SideBar implements AfterViewInit {
  @ViewChild('sidebar') sidebar!: ElementRef;

  ngAfterViewInit(): void {
    this.sidebar.nativeElement.classList.add('expanded');
  }

  toggleSidebar() {
    const el = this.sidebar.nativeElement;
    if (el.classList.contains('collapsed')) {
      el.classList.remove('collapsed');
      el.classList.add('expanded');
    } else {
      el.classList.remove('expanded');
      el.classList.add('collapsed');
    }
  }
}
