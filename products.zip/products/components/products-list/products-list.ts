import { Component, inject } from '@angular/core';
import { ProductsApi } from '../../services/products-api';
import { ProductListResponse } from '../../models/product-list-response';
import { Subscription } from 'rxjs';
import { ProductDetails } from "../product-details/product-details";

@Component({
  selector: 'bajaj-products-list',
  imports: [ProductDetails],
  templateUrl: './products-list.html',
  styleUrl: './products-list.css',
})
export class ProductsList {
  private _productApi = inject(ProductsApi);
  protected readonly title: string = "Shoppping! Shopping! Shopping!";
  protected product: ProductListResponse;
  private _subscription = new Subscription();
  protected selectedProductId: string;
  ngOnInit(): void {
    this._productApi.getproducts().subscribe({
      next: data => {
        this.product = data
        console.log(data)
      }
    });
  }
  ngOnDestroy() {
    if (this._subscription) {
      this._subscription.unsubscribe();
    }
  }
  protected onProductSelection(id: string): void {
    this.selectedProductId = id;
  }

}
